<?php

if(!defined('mnminclude')){header('Location: ../404error.php');}

//Extra fields

define('Enable_Extra_Field_1', false);
	define('Field_1_Title', 'misc field');
	define('Field_1_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_1_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_1_Required', false); 
	define('Field_1_Validation_Method', '');
	define('Field_1_Validation_Error_Message', '');

define('Enable_Extra_Field_2', false);
	define('Field_2_Title', 'misc field2');
	define('Field_2_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_2_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_2_Required', false); 
	define('Field_2_Validation_Method', '');
	define('Field_2_Validation_Error_Message', '');

define('Enable_Extra_Field_3', false);
	define('Field_3_Title', 'misc field3');
	define('Field_3_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_3_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_3_Required', false); 
	define('Field_3_Validation_Method', '');
	define('Field_3_Validation_Error_Message', '');

define('Enable_Extra_Field_4', false);
	define('Field_4_Title', 'misc field4');
	define('Field_4_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_4_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_4_Required', false); 
	define('Field_4_Validation_Method', '');
	define('Field_4_Validation_Error_Message', '');

define('Enable_Extra_Field_5', false);
	define('Field_5_Title', 'misc field5');
	define('Field_5_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_5_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_5_Required', false); 
	define('Field_5_Validation_Method', '');
	define('Field_5_Validation_Error_Message', '');

define('Enable_Extra_Field_6', false);
	define('Field_6_Title', 'misc field6');
	define('Field_6_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_6_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_6_Required', false); 
	define('Field_6_Validation_Method', '');
	define('Field_6_Validation_Error_Message', '');

define('Enable_Extra_Field_7', false);
	define('Field_7_Title', 'misc field7');
	define('Field_7_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_7_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_7_Required', false); 
	define('Field_7_Validation_Method', '');
	define('Field_7_Validation_Error_Message', '');

define('Enable_Extra_Field_8', false);
	define('Field_8_Title', 'misc field8');
	define('Field_8_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_8_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_8_Required', false); 
	define('Field_8_Validation_Method', '');
	define('Field_8_Validation_Error_Message', '');

define('Enable_Extra_Field_9', false);
	define('Field_9_Title', 'misc field9');
	define('Field_9_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_9_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_9_Required', false); 
	define('Field_9_Validation_Method', '');
	define('Field_9_Validation_Error_Message', '');

define('Enable_Extra_Field_10', false);
	define('Field_10_Title', 'misc field10');
	define('Field_10_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_10_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_10_Required', false); 
	define('Field_10_Validation_Method', '');
	define('Field_10_Validation_Error_Message', '');

define('Enable_Extra_Field_11', false);
	define('Field_11_Title', 'misc field11');
	define('Field_11_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_11_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_11_Required', false); 
	define('Field_11_Validation_Method', '');
	define('Field_11_Validation_Error_Message', '');

define('Enable_Extra_Field_12', false);
	define('Field_12_Title', 'misc field12');
	define('Field_12_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_12_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_12_Required', false); 
	define('Field_12_Validation_Method', '');
	define('Field_12_Validation_Error_Message', '');

define('Enable_Extra_Field_13', false);
	define('Field_13_Title', 'misc field13');
	define('Field_13_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_13_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_13_Required', false); 
	define('Field_13_Validation_Method', '');
	define('Field_13_Validation_Error_Message', '');

define('Enable_Extra_Field_14', false);
	define('Field_14_Title', 'misc field14');
	define('Field_14_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_14_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_14_Required', false); 
	define('Field_14_Validation_Method', '');
	define('Field_14_Validation_Error_Message', '');

define('Enable_Extra_Field_15', false);
	define('Field_15_Title', 'misc field15');
	define('Field_15_Instructions', 'this is where you put the instructions for this new field.');
	define('Field_15_Searchable', false); 
	//the variables below are not yet used in version 6.02.
	define('Field_15_Required', false); 
	define('Field_15_Validation_Method', '');
	define('Field_15_Validation_Error_Message', '');



?>