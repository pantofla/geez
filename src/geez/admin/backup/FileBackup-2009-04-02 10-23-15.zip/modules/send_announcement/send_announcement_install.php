<?php
	$module_info['name'] = 'Send Announcement';
	$module_info['desc'] = 'Send Announcement allows you to send an email to all the users of your Pligg site.';
	$module_info['version'] = 0.2;
?>