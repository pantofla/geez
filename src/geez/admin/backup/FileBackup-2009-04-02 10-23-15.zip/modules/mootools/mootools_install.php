<?php
	$module_info['name'] = 'Mootools Javascript Library';
	$module_info['desc'] = 'Mootools library from www.mootools.net.';
	$module_info['version'] = 0.1;
?>