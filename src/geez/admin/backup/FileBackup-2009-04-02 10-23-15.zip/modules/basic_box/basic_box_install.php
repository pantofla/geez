<?php
	$module_info['name'] = 'Basic Box';
	$module_info['desc'] = 'Jquery box used by other modules.';
	$module_info['version'] = 0.2;
	// $module_info['requires'][] = array('', 0.2);
?>
