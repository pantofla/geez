<?php
	$module_info['name'] = 'Scriptaculous and Prototype Javascript Library';
	$module_info['desc'] = 'Scriptaculous, Editinplace, Prototype';
	$module_info['version'] = 0.2;
?>