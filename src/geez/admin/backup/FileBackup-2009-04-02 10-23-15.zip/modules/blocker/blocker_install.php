<?php
	$module_info['name'] = 'Blocker';
	$module_info['desc'] = 'Blocks IP addresses from connecting to your site.';
	$module_info['version'] = 0.2;
	// $module_info['requires'][] = array('', 0.2);
?>
