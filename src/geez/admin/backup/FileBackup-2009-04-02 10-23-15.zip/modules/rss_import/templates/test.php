<?php
$stopwords=file('./stopwords.txt');
var_dump($stopwords);
?>
