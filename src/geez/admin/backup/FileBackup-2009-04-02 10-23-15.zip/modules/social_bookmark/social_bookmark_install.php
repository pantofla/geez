<?php
	$module_info['name'] = 'Social Bookmark';
	$module_info['desc'] = 'Adds social bookmarking to stories.';
	$module_info['version'] = 0.1;
	// $module_info['requires'][] = array('', 0.1);
?>
