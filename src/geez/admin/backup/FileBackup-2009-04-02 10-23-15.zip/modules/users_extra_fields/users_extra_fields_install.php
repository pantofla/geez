<?php
	$module_info['name'] = 'Profile Extra Fields';
	$module_info['desc'] = 'Allows modules to add extra fields to the users profile. Also known as "user_extra_fields".';
	$module_info['version'] = 0.2;
?>