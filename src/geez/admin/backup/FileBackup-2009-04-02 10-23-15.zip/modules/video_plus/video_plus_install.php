<?php
	$module_info['name'] = 'Video Plus';
	$module_info['desc'] = 'Detects and displays video in the story from a number of video sites.';
	$module_info['version'] = 0.2;
	$module_info['requires'][] = array('basic_box', 0.2);
?>
