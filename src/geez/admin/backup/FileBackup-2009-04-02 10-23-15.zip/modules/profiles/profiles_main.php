<?php

function profiles_retrieve() {

	global $current_user, $user, $db;

	$user_birthdate = $_REQUEST['user_birthdate'];
	$user_bio = $_REQUEST['user_bio'];
	$user_interests = $_REQUEST['user_interests'];
	$social_delicious = $_REQUEST['social_delicious'];
	$social_facebook = $_REQUEST['social_facebook'];
	$social_flickr = $_REQUEST['social_flickr'];
	$social_linkedin = $_REQUEST['social_linkedin'];
	$social_pownce = $_REQUEST['social_pownce'];
	$social_stumbleupon = $_REQUEST['social_stumbleupon'];
	$social_twitter = $_REQUEST['social_twitter'];
	$social_youtube = $_REQUEST['social_youtube'];
	$user_abonnement = $_REQUEST['user_abonnement'];

}

?>
