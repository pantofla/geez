<?php
	$template_info['name'] = 'Wistie'; // do not use the _ character. use - instead
	$template_info['desc'] = 'Wistie is a free and simple Pligg template';
	$template_info['author'] = 'Distie and Yankidank';
	$template_info['support'] = 'http://www.wistie.com/';
	$template_info['version'] = 1.00;
	$template_info['designed_for_pligg_version'] = '1.00';
?>
