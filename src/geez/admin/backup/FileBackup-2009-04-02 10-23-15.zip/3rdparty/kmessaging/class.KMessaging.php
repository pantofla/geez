<?php
	include('class.KMessaging_v1.2.3.php');
?>