<?php
$my_base_url = 'http://geez.gr';
$my_pligg_base = '';
$dblang = 'en';
define('table_prefix', 'pligg_');
include_once mnminclude.'settings_from_db.php';
?>