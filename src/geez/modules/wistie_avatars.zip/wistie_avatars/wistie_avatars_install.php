<?php
	$module_info['name'] = 'Wistie Avatars';
	$module_info['desc'] = 'Displays the users small avatar before the story title for (Wistie Template)';
	$module_info['version'] = 0.2;
	// $module_info['requires'][] = array('', 0.2);
?>
