<?php
	$module_info['name'] = 'Video Plus';
	$module_info['desc'] = 'Detects and displays video in the story from a number of video sites.';
	$module_info['version'] = 0.4;
	$module_info['requires'][] = array('jquery', 0.2);
?>
