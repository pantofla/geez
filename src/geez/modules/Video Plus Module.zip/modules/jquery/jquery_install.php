<?php
	$module_info['name'] = 'jQuery Javascript Library';
	$module_info['desc'] = 'jQuery library from www.jquery.com. Also includes select plugins for additional effects.';
	$module_info['version'] = 0.2;
?>