<?php
	$module_info['name'] = 'Queue Bar';
	$module_info['desc'] = 'Displays the number of upcoming stories in the sidebar.';
	$module_info['version'] = 0.2;
	// $module_info['requires'][] = array('', 0.2);
?>
